# Food_Delivery_App_Data_Analysis
This project provided hands-on experience with a real-world dataset from Zomato, a leading food delivery app. The primary aim of the project was to clean and analyze the dataset to uncover useful insights and information. To achieve this, Python was utilized for preprocessing and cleaning the data, while SQL was used to perform the data analysis. 
